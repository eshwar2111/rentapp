package com.example.rentapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
