import 'package:flutter/material.dart';
class rentapp extends StatefulWidget {
  const rentapp({super.key});

  @override
  State <rentapp> createState() =>  rentappState();
}

class  rentappState extends State <rentapp> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}